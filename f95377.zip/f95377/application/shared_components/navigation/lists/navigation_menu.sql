prompt --application/shared_components/navigation/lists/navigation_menu
begin
--   Manifest
--     LIST: Navigation Menu
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>28566192935880112740
,p_default_application_id=>95377
,p_default_id_offset=>0
,p_default_owner=>'WKSP_ARINA30'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(29053306588386084271)
,p_name=>'Navigation Menu'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(29053502894376084355)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Home'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(29317836324018799279)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>unistr('\0421\043E\0442\0440\0443\0434\043D\0438\043A\0438 \043E\0442\0434\0435\043B\0430')
,p_list_item_link_target=>'f?p=&APP_ID.:16:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(29053502894376084355)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'16'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(29421815803098559497)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>unistr('\0421\043E\0442\0440\0443\0434\043D\0438\043A\0438 \0441\043E \0441\0442\0430\0436\0435\043C \0440\0430\0431\043E\0442\044B \043D\0435 \043C\0435\043D\0435\0435 5-\0438 \043B\0435\0442')
,p_list_item_link_target=>'f?p=&APP_ID.:20:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(29053502894376084355)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'20,21'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(29423664065084590389)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>unistr('\0421\043E\0442\0440\0443\0434\043D\0438\043A \0440\0430\0431\043E\0442\0430\044E\0449\0438\0439 \043D\0430 \043E\0434\043D\043E\0439 \0434\043E\043B\0436\043D\043E\0441\0442\0438')
,p_list_item_link_target=>'f?p=&APP_ID.:22:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(29053502894376084355)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'22,23'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(29424137830881649204)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>unistr('\0422\0435\043A\0443\0449\0438\0435 \0434\043E\043B\0436\043D\043E\0441\0442\0438 \0441\043E\0442\0440\0443\0434\043D\0438\043A\043E\0432 \043F\043E \043E\0442\0434\0435\043B\0430\043C (\0431\0435\0437 \043F\043E\0432\0442\043E\0440\043E\0432)')
,p_list_item_link_target=>'f?p=&APP_ID.:24:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(29053502894376084355)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'24,25'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(29424638578082685844)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>unistr('\0421\043E\0442\0440\0443\0434\043D\0438\043A\0438, \0441\043C\0435\043D\0438\0432\0448\0438\0435 \0431\043E\043B\0435\0435 3-\0435\0445 \0434\043E\043B\0436\043D\043E\0441\0442\0435\0439')
,p_list_item_link_target=>'f?p=&APP_ID.:26:&APP_SESSION.::&DEBUG.:::'
,p_parent_list_item_id=>wwv_flow_api.id(29053502894376084355)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'26,27'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(29055149507131100112)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('\0421\043E\0442\0440\0443\0434\043D\0438\043A\0438')
,p_list_item_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-id-card-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'3,4'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(29055907435442148168)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>unistr('\0414\043E\043B\0436\043D\043E\0441\0442\0438')
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-user-edit'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'5,6'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(29055938359273152394)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>unistr('\041E\0442\0434\0435\043B\044B')
,p_list_item_link_target=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-users-alt'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'7,8'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(29056456216156119094)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>unistr('\0422\0440\0443\0434\043E\0432\0430\044F \043A\043D\0438\0436\043A\0430')
,p_list_item_link_target=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-address-book-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'9,10'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(29309303219622513295)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>unistr('\041F\043E\0432\044B\0448\0435\043D\0438\0435 \0437\0430\0440\0430\0431\043E\0442\043D\043E\0439 \043F\043B\0430\0442\044B')
,p_list_item_link_target=>'f?p=&APP_ID.:14:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'14'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(29313453018742704151)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>unistr('\0423\0432\043E\043B\044C\043D\0435\043D\0438\0435 \0411\0423\0413\0413\0410\0413\0410\0413\0410')
,p_list_item_link_target=>'f?p=&APP_ID.:15:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'15'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(29640305480066353693)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>unistr('\0410\0440\0445\0438\0432')
,p_list_item_link_target=>'f?p=&APP_ID.:11:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'11,12'
);
wwv_flow_api.component_end;
end;
/
