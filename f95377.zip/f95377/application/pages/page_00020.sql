prompt --application/pages/page_00020
begin
--   Manifest
--     PAGE: 00020
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>28566192935880112740
,p_default_application_id=>95377
,p_default_id_offset=>0
,p_default_owner=>'WKSP_ARINA30'
);
wwv_flow_api.create_page(
 p_id=>20
,p_user_interface_id=>wwv_flow_api.id(29053494320349084346)
,p_name=>unistr('\0421\043E\0442\0440\0443\0434\043D\0438\043A\0438 \0441\043E \0441\0442\0430\0436\0435\043C \0440\0430\0431\043E\0442\044B \043D\0435 \043C\0435\043D\0435\0435 5-\0438 \043B\0435\0442')
,p_alias=>unistr('\0421\041E\0422\0420\0423\0414\041D\0418\041A\0418-\0421\041E-\0421\0422\0410\0416\0415\041C-\0420\0410\0411\041E\0422\042B-\041D\0415-\041C\0415\041D\0415\0415-5-\0418-\041B\0415\04222')
,p_step_title=>unistr('\0421\043E\0442\0440\0443\0434\043D\0438\043A\0438 \0441\043E \0441\0442\0430\0436\0435\043C \0440\0430\0431\043E\0442\044B \043D\0435 \043C\0435\043D\0435\0435 5-\0438 \043B\0435\0442')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'LATYSHEVA.YY@YANDEX.RU'
,p_last_upd_yyyymmddhh24miss=>'20220112181808'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(29421806138396556365)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(29053392600715084305)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select tabel, fio, ROUND(exp+((SYSDATE - entrydate)/365),2)as exp from employee where exp>=5;',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Report 1'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(29421806595081556365)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.:RP:P21_TABEL:\#TABEL#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'LATYSHEVA.YY@YANDEX.RU'
,p_internal_uid=>29421806595081556365
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(29421806675896556366)
,p_db_column_name=>'TABEL'
,p_display_order=>0
,p_column_identifier=>'A'
,p_column_label=>'Tabel'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(29421807035371556366)
,p_db_column_name=>'FIO'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Fio'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(29421807476919556367)
,p_db_column_name=>'EXP'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Exp'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(29422370972006613329)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'294223710'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TABEL:FIO:EXP'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(29421816597973559498)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(29421806138396556365)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(29053469574532084335)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.:21'
);
wwv_flow_api.component_end;
end;
/
