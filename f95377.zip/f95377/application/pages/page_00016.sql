prompt --application/pages/page_00016
begin
--   Manifest
--     PAGE: 00016
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>28566192935880112740
,p_default_application_id=>95377
,p_default_id_offset=>0
,p_default_owner=>'WKSP_ARINA30'
);
wwv_flow_api.create_page(
 p_id=>16
,p_user_interface_id=>wwv_flow_api.id(29053494320349084346)
,p_name=>unistr('\0421\043E\0442\0440\0443\0434\043D\0438\043A\0438 \043E\0442\0434\0435\043B\0430')
,p_alias=>unistr('\0421\041E\0422\0420\0423\0414\041D\0418\041A\0418-\041E\0422\0414\0415\041B\0410')
,p_step_title=>unistr('\0421\043E\0442\0440\0443\0434\043D\0438\043A\0438 \043E\0442\0434\0435\043B\0430')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'LATYSHEVA.YY@YANDEX.RU'
,p_last_upd_yyyymmddhh24miss=>'20220112175839'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(29317836694771799280)
,p_plug_name=>unistr('\0421\043E\0442\0440\0443\0434\043D\0438\043A\0438 \043E\0442\0434\0435\043B\0430')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(29053392600715084305)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>'select otdel.name_otdel, FIO from employee inner join otdel on otdel = id_otdel;'
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>unistr('\0421\043E\0442\0440\0443\0434\043D\0438\043A\0438 \043E\0442\0434\0435\043B\0430')
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(29317836729369799280)
,p_name=>unistr('\0421\043E\0442\0440\0443\0434\043D\0438\043A\0438 \043E\0442\0434\0435\043B\0430')
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'LATYSHEVA.YY@YANDEX.RU'
,p_internal_uid=>29317836729369799280
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(29317837122285799281)
,p_db_column_name=>'NAME_OTDEL'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Name Otdel'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(29317837585804799283)
,p_db_column_name=>'FIO'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Fio'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(29317845149705801406)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'293178452'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NAME_OTDEL:FIO'
);
wwv_flow_api.component_end;
end;
/
