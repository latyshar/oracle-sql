prompt --application/pages/page_00026
begin
--   Manifest
--     PAGE: 00026
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>28566192935880112740
,p_default_application_id=>95377
,p_default_id_offset=>0
,p_default_owner=>'WKSP_ARINA30'
);
wwv_flow_api.create_page(
 p_id=>26
,p_user_interface_id=>wwv_flow_api.id(29053494320349084346)
,p_name=>unistr('\0421\043E\0442\0440\0443\0434\043D\0438\043A\0438, \0441\043C\0435\043D\0438\0432\0448\0438\0435 \0431\043E\043B\0435\0435 3-\0435\0445 \0434\043E\043B\0436\043D\043E\0441\0442\0435\0439')
,p_alias=>unistr('\0421\041E\0422\0420\0423\0414\041D\0418\041A\0418-\0421\041C\0415\041D\0418\0412\0428\0418\0415-\0411\041E\041B\0415\0415-3-\0415\0425-\0414\041E\041B\0416\041D\041E\0421\0422\0415\04191')
,p_step_title=>unistr('\0421\043E\0442\0440\0443\0434\043D\0438\043A\0438, \0441\043C\0435\043D\0438\0432\0448\0438\0435 \0431\043E\043B\0435\0435 3-\0435\0445 \0434\043E\043B\0436\043D\043E\0441\0442\0435\0439')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'LATYSHEVA.YY@YANDEX.RU'
,p_last_upd_yyyymmddhh24miss=>'20220112183801'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(29424618378980682907)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(29053392600715084305)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select employee.fio, employee, tabel from emplbook  inner join employee on tabel=employee group by employee,fio,tabel having count(employee)>3;',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Report 1'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(29424618724098682908)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.:RP:P27_TABEL:\#TABEL#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'LATYSHEVA.YY@YANDEX.RU'
,p_internal_uid=>29424618724098682908
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(29424619784709682910)
,p_db_column_name=>'TABEL'
,p_display_order=>0
,p_column_identifier=>'C'
,p_column_label=>'Tabel'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(29424618850730682908)
,p_db_column_name=>'FIO'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Fio'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(29424619375269682910)
,p_db_column_name=>'EMPLOYEE'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Employee'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(29426072040992693600)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'294260721'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TABEL:FIO:EMPLOYEE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(29424639248951685844)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(29424618378980682907)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(29053469574532084335)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.:27'
);
wwv_flow_api.component_end;
end;
/
