prompt --application/pages/page_00015
begin
--   Manifest
--     PAGE: 00015
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>28566192935880112740
,p_default_application_id=>95377
,p_default_id_offset=>0
,p_default_owner=>'WKSP_ARINA30'
);
wwv_flow_api.create_page(
 p_id=>15
,p_user_interface_id=>wwv_flow_api.id(29053494320349084346)
,p_name=>unistr('\0423\0432\043E\043B\044C\043D\0435\043D\0438\0435 \0411\0423\0413\0413\0410\0413\0410\0413\0410')
,p_alias=>unistr('\0423\0412\041E\041B\042C\041D\0415\041D\0418\0415-\0411\0423\0413\0413\0410\0413\0410\0413\0410')
,p_step_title=>unistr('\0423\0432\043E\043B\044C\043D\0435\043D\0438\0435 \0411\0423\0413\0413\0410\0413\0410\0413\0410')
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(29053497296961084350)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'LATYSHEVA.YY@YANDEX.RU'
,p_last_upd_yyyymmddhh24miss=>'20220112101316'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(29313453499877704151)
,p_plug_name=>unistr('\0423\0432\043E\043B\044C\043D\0435\043D\0438\0435 \0411\0423\0413\0413\0410\0413\0410\0413\0410')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(29053396957504084306)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(29313453938085704152)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(29313453499877704151)
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(29053469574532084335)
,p_button_image_alt=>'Submit'
,p_button_position=>'CHANGE'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(29313453813965704152)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(29313453499877704151)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(29053469574532084335)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(29313454730083704152)
,p_name=>'P15_BEL1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(29313453499877704151)
,p_prompt=>unistr('ID \0441\043E\0442\0440\0443\0434\043D\0438\043A\0430')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(29053467015480084334)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(29313455114773704153)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Run Stored Procedure'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'"#OWNER#"."DISMISS"(',
'"TABEL1" => :P15_BEL1);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(29313453938085704152)
);
wwv_flow_api.component_end;
end;
/
