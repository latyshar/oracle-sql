prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>28566192935880112740
,p_default_application_id=>95377
,p_default_id_offset=>0
,p_default_owner=>'WKSP_ARINA30'
);
wwv_flow_api.create_page(
 p_id=>7
,p_user_interface_id=>wwv_flow_api.id(29053494320349084346)
,p_name=>unistr('\041E\0442\0434\0435\043B\044B')
,p_alias=>unistr('\041E\0422\0414\0415\041B\042B1')
,p_step_title=>unistr('\041E\0442\0434\0435\043B\044B')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'LATYSHEVA.YY@YANDEX.RU'
,p_last_upd_yyyymmddhh24miss=>'20220111160226'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(29055937060118152393)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(29053392600715084305)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'OTDEL'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Report 1'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(29055937467099152393)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:RP:P8_ID_OTDEL:\#ID_OTDEL#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'LATYSHEVA.YY@YANDEX.RU'
,p_internal_uid=>29055937467099152393
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(29055937553716152393)
,p_db_column_name=>'ID_OTDEL'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Id Otdel'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(29055937916680152394)
,p_db_column_name=>'NAME_OTDEL'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Name Otdel'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(29056559861910120152)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'290565599'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID_OTDEL:NAME_OTDEL'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(29055939123276152395)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(29055937060118152393)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(29053469574532084335)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:8'
);
wwv_flow_api.component_end;
end;
/
