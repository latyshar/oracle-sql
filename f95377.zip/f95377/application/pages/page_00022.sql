prompt --application/pages/page_00022
begin
--   Manifest
--     PAGE: 00022
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>28566192935880112740
,p_default_application_id=>95377
,p_default_id_offset=>0
,p_default_owner=>'WKSP_ARINA30'
);
wwv_flow_api.create_page(
 p_id=>22
,p_user_interface_id=>wwv_flow_api.id(29053494320349084346)
,p_name=>unistr('\0421\043E\0442\0440\0443\0434\043D\0438\043A \0440\0430\0431\043E\0442\0430\044E\0449\0438\0439 \043D\0430 \043E\0434\043D\043E\0439 \0434\043E\043B\0436\043D\043E\0441\0442\0438')
,p_alias=>unistr('\0421\041E\0422\0420\0423\0414\041D\0418\041A-\0420\0410\0411\041E\0422\0410\042E\0429\0418\0419-\041D\0410-\041E\0414\041D\041E\0419-\0414\041E\041B\0416\041D\041E\0421\0422\04181')
,p_step_title=>unistr('\0421\043E\0442\0440\0443\0434\043D\0438\043A \0440\0430\0431\043E\0442\0430\044E\0449\0438\0439 \043D\0430 \043E\0434\043D\043E\0439 \0434\043E\043B\0436\043D\043E\0441\0442\0438')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'LATYSHEVA.YY@YANDEX.RU'
,p_last_upd_yyyymmddhh24miss=>'20220112182149'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(29423639730948586986)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(29053392600715084305)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT tabel, employee.fio, positions FROM emplbook inner join employee on tabel=employee GROUP BY positions, fio, tabel HAVING count(positions) > 1;',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Report 1'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(29423640166282586986)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:RP:P23_TABEL:\#TABEL#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'LATYSHEVA.YY@YANDEX.RU'
,p_internal_uid=>29423640166282586986
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(29423640240831586986)
,p_db_column_name=>'TABEL'
,p_display_order=>0
,p_column_identifier=>'A'
,p_column_label=>'Tabel'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(29423640606945586987)
,p_db_column_name=>'FIO'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Fio'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(29423641095953586987)
,p_db_column_name=>'POSITIONS'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Positions'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(29423880816420596456)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'294238809'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TABEL:FIO:POSITIONS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(29423664733424590389)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(29423639730948586986)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(29053469574532084335)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:23'
);
wwv_flow_api.component_end;
end;
/
