prompt --application/pages/page_00014
begin
--   Manifest
--     PAGE: 00014
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>28566192935880112740
,p_default_application_id=>95377
,p_default_id_offset=>0
,p_default_owner=>'WKSP_ARINA30'
);
wwv_flow_api.create_page(
 p_id=>14
,p_user_interface_id=>wwv_flow_api.id(29053494320349084346)
,p_name=>unistr('\041F\043E\0432\044B\0448\0435\043D\0438\0435 \0437\0430\0440\0430\0431\043E\0442\043D\043E\0439 \043F\043B\0430\0442\044B ')
,p_alias=>unistr('\041F\041E\0412\042B\0428\0415\041D\0418\0415-\0417\0410\0420\0410\0411\041E\0422\041D\041E\0419-\041F\041B\0410\0422\042B')
,p_step_title=>unistr('\041F\043E\0432\044B\0448\0435\043D\0438\0435 \0437\0430\0440\0430\0431\043E\0442\043D\043E\0439 \043F\043B\0430\0442\044B ')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'LATYSHEVA.YY@YANDEX.RU'
,p_last_upd_yyyymmddhh24miss=>'20220112094200'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(29309303679533513296)
,p_plug_name=>unistr('\041F\043E\0432\044B\0448\0435\043D\0438\0435 \0437\0430\0440\0430\0431\043E\0442\043D\043E\0439 \043F\043B\0430\0442\044B ')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(29053396957504084306)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(29309304115592513296)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(29309303679533513296)
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(29053469574532084335)
,p_button_image_alt=>'Submit'
,p_button_position=>'CHANGE'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(29309304030381513296)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(29309303679533513296)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(29053469574532084335)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(29309304927865513297)
,p_name=>'P14_S_CODE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(29309303679533513296)
,p_prompt=>unistr('\0414\043E\043B\0436\043D\043E\0441\0442\044C')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(29053467015480084334)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(29309305385980513297)
,p_name=>'P14_EMIA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(29309303679533513296)
,p_prompt=>'%'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(29053467015480084334)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(29309305721135513297)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Run Stored Procedure'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'"#OWNER#"."PREMIA"(',
'"POS_CODE" => :P14_S_CODE,',
'"PREMIA" => :P14_EMIA);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(29309304115592513296)
);
wwv_flow_api.component_end;
end;
/
