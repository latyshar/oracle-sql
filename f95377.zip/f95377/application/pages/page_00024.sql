prompt --application/pages/page_00024
begin
--   Manifest
--     PAGE: 00024
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>28566192935880112740
,p_default_application_id=>95377
,p_default_id_offset=>0
,p_default_owner=>'WKSP_ARINA30'
);
wwv_flow_api.create_page(
 p_id=>24
,p_user_interface_id=>wwv_flow_api.id(29053494320349084346)
,p_name=>unistr('\0422\0435\043A\0443\0449\0438\0435 \0434\043E\043B\0436\043D\043E\0441\0442\0438 \0441\043E\0442\0440\0443\0434\043D\0438\043A\043E\0432 \043F\043E \043E\0442\0434\0435\043B\0430\043C (\0431\0435\0437 \043F\043E\0432\0442\043E\0440\043E\0432)')
,p_alias=>unistr('\0422\0415\041A\0423\0429\0418\0415-\0414\041E\041B\0416\041D\041E\0421\0422\0418-\0421\041E\0422\0420\0423\0414\041D\0418\041A\041E\0412-\041F\041E-\041E\0422\0414\0415\041B\0410\041C-\0411\0415\0417-\041F\041E\0412\0422\041E\0420\041E\04121')
,p_step_title=>unistr('\0422\0435\043A\0443\0449\0438\0435 \0434\043E\043B\0436\043D\043E\0441\0442\0438 \0441\043E\0442\0440\0443\0434\043D\0438\043A\043E\0432 \043F\043E \043E\0442\0434\0435\043B\0430\043C (\0431\0435\0437 \043F\043E\0432\0442\043E\0440\043E\0432)')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'LATYSHEVA.YY@YANDEX.RU'
,p_last_upd_yyyymmddhh24miss=>'20220112182801'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(29424086686406645941)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(29053392600715084305)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DISTINCT otdel.name_otdel, positions.name_pos, tabel from employee inner join otdel on otdel = id_otdel inner join positions on pos=id_pos;',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Report 1'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(29424087074502645941)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:RP:P25_TABEL:\#TABEL#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'LATYSHEVA.YY@YANDEX.RU'
,p_internal_uid=>29424087074502645941
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(29424087936703645945)
,p_db_column_name=>'TABEL'
,p_display_order=>0
,p_column_identifier=>'C'
,p_column_label=>'Tabel'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(29424087134983645942)
,p_db_column_name=>'NAME_OTDEL'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Name Otdel'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(29424087545041645945)
,p_db_column_name=>'NAME_POS'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Name Pos'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(29424408160073672633)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'294244082'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TABEL:NAME_OTDEL:NAME_POS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(29424138535034649204)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(29424086686406645941)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(29053469574532084335)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:25'
);
wwv_flow_api.component_end;
end;
/
